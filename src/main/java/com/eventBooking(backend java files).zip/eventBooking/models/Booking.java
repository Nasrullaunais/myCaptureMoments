package com.eventBooking.models;


public class Booking {
    private String username;
    private String providerName;
    private String eventDate;
    private String location;
    private String type;
    private String status; // pending, confirmed, completed

    public Booking(String username, String providerName, String eventDate, String location, String type, String status) {
        this.username = username;
        this.providerName = providerName;
        this.eventDate = eventDate;
        this.location = location;
        this.type = type;
        this.status = status;
    }

    public String getUsername() { return username; }
    public String getProviderName() { return providerName; }
    public String getEventDate() { return eventDate; }
    public String getLocation() { return location; }
    public String getType() { return type; }
    public String getStatus() { return status; }

    public void setStatus(String status) {
        this.status = status;
    }

    public String toFileString() {
        return username + "," + providerName + "," + eventDate + "," + location + "," + type + "," + status;
    }

    public static Booking fromFileString(String line) {
        String[] parts = line.split(",");
        return new Booking(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]);
    }
}
