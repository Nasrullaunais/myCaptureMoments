package com.eventBooking.controllers;


import com.eventBooking.models.Booking;
import com.eventBooking.models.Photographer;
import com.eventBooking.services.PhotographerService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.eventBooking.services.BookingService;

import java.util.List;


@Controller
@RequestMapping("/bookings")
public class BookingController {

    private final BookingService bookingService = new BookingService();
    private final PhotographerService photographerService = new PhotographerService();

    @GetMapping("/new")
    public String showBookingForm(Model model, HttpSession session) {
        if (session.getAttribute("username") == null) {
            return "redirect:/login";
        }

        List<Photographer> providers = photographerService.getAllPhotographers();
        model.addAttribute("providers", providers);
        return "redirect:/booking.html";
    }

    @PostMapping("/create")
    public String createBooking(@RequestParam String providerName,
                                @RequestParam String eventDate,
                                @RequestParam String location,
                                @RequestParam String type,
                                HttpSession session) {
        String username = (String) session.getAttribute("username");
        if (username == null) {
            return "redirect:/login";
        }

        Booking booking = new Booking(username, providerName, eventDate, location, type, "pending");
        bookingService.createBooking(booking);

        return "redirect:/bookings/manage";
    }

    @GetMapping("/manage")
    public String viewBookings(Model model, HttpSession session) {
        String username = (String) session.getAttribute("username");
        if (username == null) {
            return "redirect:/login";
        }

        List<Booking> bookings = bookingService.getBookingsByUser(username);
        model.addAttribute("bookings", bookings);
        return "redirect:/manage.html";
    }

    @PostMapping("/cancel")
    public String cancelBooking(@RequestParam String providerName, HttpSession session) {
        String username = (String) session.getAttribute("username");
        if (username == null) {
            return "redirect:/login";
        }

        bookingService.deleteBooking(username, providerName);
        return "redirect:/bookings/manage";
    }
}
