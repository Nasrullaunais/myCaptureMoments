package com.eventBooking.controllers;

import com.eventBooking.models.User;
import com.eventBooking.services.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

@Controller
public class AuthController {
    private final UserService userService = new UserService();

    @GetMapping("/")
    public String home() {
        return "redirect:/index.html";
    }

    @GetMapping("/login")
    public String login() {
        return "redirect:/login.html";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        @RequestParam String role,
                        HttpSession session, Model model) {
        if(userService.validateLogin(username, password)) {
            session.setAttribute("username", username);
            session.setAttribute("password", password);
            session.setAttribute("role", role);
            if(role.equals("admin")) {
                return "redirect:/admin-dashboard.html";
            }
            else {
                return "redirect:/dashboard.html";
            }
        }
        else {
            model.addAttribute("message", "Invalid username or password");
            return "redirect:/login";
        }
    }

    @GetMapping("/register")
    public String register() {
        return "redirect:/register";
    }

    @PostMapping("/register")
    public String register(@RequestParam String username,
                           @RequestParam String password,
                           HttpSession session, Model model) {
        User newUser = new User(username, password, "user");
        if (userService.registerUser(newUser)){
            return "redirect:/dashboard.html";
        }
        else {
            model.addAttribute("message", "User already exists");
            return "redirect:/login";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/index.html";
    }


}
